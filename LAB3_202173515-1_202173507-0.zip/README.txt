Nombres                  Rol            Rut         Paralelo
Nicolas Rodriguez     202173515-1   20793631-6          201
Benjamín Aguilera     202173507-0   20836696-3          201

Se rellenó la ROM directamente en el archivo de diseño, no en el testbench.